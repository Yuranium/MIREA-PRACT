﻿// ConsoleApplication11.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
using namespace std;

int** graph_create(int& graph_size, char*& names_out) {
	int temp, size;
	char temp2;
	cout << "Введите количество узлов в графе > ";
	cin >> size;
	graph_size = size;
	int** GR = new int* [size]; // Двумерный массив графа
	char* names = new char[size + 1]; // Массив имён узлов
	cout << "Вводите поочерёдно буквы-названия узлов в графе:" << endl;
	for (int count = 0; count < size; count++)
	{
		GR[count] = new int[size];
		cin >> temp2;
		names[count + 1] = temp2;
	}
	names_out = names;
	for (int i = 0; i < size; i++)
	{
		GR[i][i] = 0; // Заполнение нулями диагонали
		for (int j = i + 1; j < size; j++) {
			cout << "Введите расстояние " << names[i + 1] << " - " << names[j + 1] << " : > ";
			cin >> temp;
			GR[i][j] = temp; // Заполнение снизу диагонали
			GR[j][i] = temp; // Заполнение сверху диагонали
		}
	}
	return GR;
}

void graph_delete(int** GR, int size) {
	for (int count = 0; count < size; count++) // Удаление двумерного массива графа
		delete[]GR[count];
}

void dijkstra(int** GR, int st, int size, char* names) {
	int count, index, i, u, m = st + 1;
	int* distance = new int[size]; // Минимальное расстояние
	bool* visited = new bool[size]; // Посещённые вершины
	for (i = 0; i < size; i++)
	{
		distance[i] = INT_MAX; // Инициализируем расстояния до вершин бесконечностью
		visited[i] = false; // Помечаем вершины непосещёнными
	}
	distance[st] = 0; // Расстояние у начальной вершины 0
	for (count = 0; count < size - 1; count++)
	{
		int min = INT_MAX; // Изначально минимум равен бесконечности
		for (i = 0; i < size; i++)
		{
			if (!visited[i] && distance[i] <= min) // Перебираем среди непосещенных вершин
			{									// вершину с минимальным расстоянием
				min = distance[i];
				index = i; // Запоминаем индекс вершины
			}
		}
		u = index;
		visited[u] = true; // Отмечаем найденную вершину посещённой
		for (i = 0; i < size; i++)
		{
			if (!visited[i] && GR[u][i] && distance[u] != INT_MAX && distance[u] + GR[u][i] < distance[i])
			{ // Если в вершину есть путь и сумма расстояния и значения метки меньше предыдущего значения
				distance[i] = distance[u] + GR[u][i]; // Присваиваем прошлую метку расстояния и прибавляем к ней текущее растояние
			}
		}
	}
	cout << "Стоимость пути из начальной вершины до остальных:\t\n";
	for (i = 0; i < size; i++)
	{
		if (distance[i] != INT_MAX) // Если в метке расстояния не бесконечность
			cout << names[m] << " > " << names[i + 1] << " = " << distance[i] << endl;
		else
			cout << names[m] << " > " << names[i + 1] << " = " << "маршрут недоступен" << endl;
	}
}


void print(int** GR, char* names, int size) {
	for (int i = -1; i < size; i++)
	{
		if (i != -1)
			cout << names[i + 1]; // Буквы на левом столбце
		for (int j = 0; j < size; j++)
		{
			if (i == -1)
			{
				cout << "\t" << names[j + 1]; // Буквы на верхней строке
			}
			else
				cout << "\t" << GR[i][j]; // Значения матрицы
		}
		cout << "\n";
	}
}


int main() {
	setlocale(0, "");
	char* names;
	int choice = -1, graph_size = 0;
	int** GR = graph_create(graph_size, names); // Создание графа
	while (choice != 0)
	{
		cout << "Какая операция необходима?\n";
		cout << "1. Поиск кратчайших путей из вершины до остальных вершин\n";
		cout << "2. Вывести таблицу отношений в графе\n";
		cout << "3. Пересоздать граф\n";
		cout << "0. Выход\n";
		cin >> choice;
		switch (choice)
		{
		case 1:
		{
			int start = 0;
			char name;
			cout << "Вершина из которой искать пути > ";
			cin >> name;
			for (int i = 0; i <= graph_size; i++)
			{ // Перевод ввёдённого названия в индекс
				if (names[i] == name)
				{
					start = i - 1;
				}
			}
			dijkstra(GR, start, graph_size, names);
			break;
		}
		case 2:
			print(GR, names, graph_size);
			break;
		case 3:
		{
			graph_delete(GR, graph_size);
			int** GR = graph_create(graph_size, names);
			break;
		}
		case 0:
			break;
		default:
			break;
		}
	}
	return 0;
}

