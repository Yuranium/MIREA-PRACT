﻿#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;
vector<string> findWordsWithSubstring(const string& substring, const string& text) {
    vector<string> result;
    string word;

    for (char c : text) {
        if (isalpha(c)) {
            word += c;
        }
        else {
            if (!word.empty() && word.length() >= substring.length() && word.substr(word.length() - substring.length()) == substring) {
                result.push_back(word);
            }
            word = "";
        }
    }

    return result;
}

int RabinKarp(const string& pattern, const string& text) {
    int count = 0;
    int patternLength = pattern.length();
    int textLength = text.length();
    int patternHash = 0;
    int textHash = 0;
    const int prime = 101; // Простое число для хэширования

    // Вычисление хэша для образца и первого фрагмента текста
    for (int i = 0; i < patternLength; i++) {
        patternHash += pattern[i] * pow(prime, i);
        textHash += text[i] * pow(prime, i);
    }

    // Проход по тексту
    for (int i = 0; i <= textLength - patternLength; i++) {
        // Сравнение хэшей
        if (patternHash == textHash) {
            // Сравнение посимвольно
            int j;
            for (j = 0; j < patternLength; j++) {
                if (text[i + j] != pattern[j]) {
                    break;
                }
            }
            if (j == patternLength) {
                count++;
            }
        }

        // Обновление хэша
        textHash = (prime * (textHash - text[i] * pow(prime, 0))) + text[i + patternLength] * pow(prime, patternLength - 1);
    }

    return count;
}

int main() {
    using namespace std;
    setlocale(LC_ALL, "Russian");
    ifstream fileInput("input.txt");

    if (!fileInput.is_open()) {
        cout << "Can't open file!" << endl;
        return 1;
    }

    string substring;
    getline(fileInput, substring);
    string text;
    getline(fileInput, text);

    fileInput.close();

    vector<string> words = findWordsWithSubstring(substring, text);

    cout << "Слова с подстрокой в конце:" << endl;
    for (const string& word : words) {
        cout << word << endl;
    }

    int count = RabinKarp(substring, text);
    cout << "Количество вхождений подстроки: " << count << endl;

    return 0;
}
