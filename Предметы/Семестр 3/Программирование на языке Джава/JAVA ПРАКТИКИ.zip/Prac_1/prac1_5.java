public class prac1_5 {
    public static void prac1_5(String[] args) {
        for (String str : args) {
            System.out.println("Аргумент = " + str);
        }
    }
}
