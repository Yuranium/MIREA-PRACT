public class NameableTester {
    public static void main(String[] arg) {
        Nameable car = new Car("Lada Granta","LADA","Silver", 78);
        System.out.println(car.getName());
        System.out.println(car);
        Nameable animal = new Animal("Собака","Бим","Мальчик",2);
        System.out.println(animal.getName());
        System.out.println(animal);
    }
}
