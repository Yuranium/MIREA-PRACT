public class MovableRectangleTester2 {
    public static void main(String[] args) {
        MovableRectangle2 r2 = new MovableRectangle2(30, 30, 50, 0, 20, 20, 20,20);
        System.out.println(r2);
        r2.moveLeft();
        r2.moveDown();
        System.out.println(r2);
        System.out.println(r2.SpeedTest());
    }
}
