public class MovablePointTester {
    public static void main(String[] args) {
        MovablePoint point = new MovablePoint(30,20,15,20);
        point.moveUp();
        point.moveLeft();
        System.out.println(point);
    }
}
