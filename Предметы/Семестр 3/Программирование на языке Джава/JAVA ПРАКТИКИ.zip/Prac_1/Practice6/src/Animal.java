public class Animal implements Nameable{
    private final String name;
    private final String type;
    private final int age;
    private final String sex;
    public String getName()
    {
        return name;
    }
    public String getType()
    {
        return type;
    }
    public int getAge()
    {
        return age;
    }
    public String getSex()
    {
     return sex;
    }
    Animal(String type, String name, String sex, int age)
    {
        this.name = name;
        this.type = type;
        this.sex = sex;
        this.age = age;
    }

    @Override
    public String toString() {
        return (type + " " + name + " " + sex + " " + age + " год(а)"  );
    }
}
