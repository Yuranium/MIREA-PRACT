public class MovableRectangleTester {
    public static void main(String[] args) {
        MovableRectangle r1 = new MovableRectangle(30, 30, 50, 0, 20, 20);
        System.out.println(r1);
        r1.moveLeft();
        r1.moveDown();
        System.out.println(r1);

    }
}
