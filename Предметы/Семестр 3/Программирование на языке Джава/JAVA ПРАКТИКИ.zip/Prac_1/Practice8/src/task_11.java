import java.util.Scanner;
public class task_11 {
    public static int recursion() {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        if (n > 1) {return recursion();}        // если число не равно ни 0 ни 1  - то игнорируем его: запускаем рекурсию снова
        if (n == 1) {return recursion() + 1;}   // если число = 1, то возвращаем + 1
        // проверка, если введён был 0
        if (n == 0) {
            int f = in.nextInt();               // 2-ой инпут, для обработки случая двух нулей
            if (f == 0) return 0;               // если был введён ещё один ноль, тоесть 2 нуля подряд, то выходим из рекурсии
            if (f == 1) return recursion() + 1;   // если второе число 1, то возвращаем + 1
            else return recursion();            // иначе у нас случай, что число и не 0 и не 1, тогда вызываем рекурсию снова

        }
        return recursion();

    }

    public static void main(String[] args) {

        System.out.println(recursion());

    }
}
