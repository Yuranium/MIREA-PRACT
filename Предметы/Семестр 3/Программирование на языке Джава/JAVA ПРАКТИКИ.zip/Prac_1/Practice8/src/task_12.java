import java.util.Scanner;
public class task_12 {
    public  static void recursion() {
        java.util.Scanner in = new Scanner(System.in);
        int digit = in.nextInt();
        if (digit > 0) {
            if (digit % 2 == 1) {
                System.out.println(digit);
                recursion();
            } else {
                recursion();
            }
        }

    }
    public static void main(String[] args) {
        recursion();
    }
}
