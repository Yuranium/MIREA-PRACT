import java.lang.Math;
public class MathFunc implements MathCalculable
{
        @Override
        public double toPow(double a,double b)
        {
            return Math.pow(a,b);
        };
        @Override
        public double absComplex(double re, double im)
        {
            Complex complex = new Complex(re, im);
            return (complex.abs());
        };

        public double circleLenght(double r) {

            return (2*PI*r);
        }
}

