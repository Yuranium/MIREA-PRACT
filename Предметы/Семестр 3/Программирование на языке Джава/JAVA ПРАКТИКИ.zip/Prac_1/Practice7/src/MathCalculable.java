public interface MathCalculable {
    double toPow(double a, double b);
    double absComplex(double re, double im);
    double PI = 3.14;
}
