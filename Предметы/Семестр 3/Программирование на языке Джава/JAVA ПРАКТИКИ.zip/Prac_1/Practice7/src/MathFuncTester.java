public class MathFuncTester {
    public static void main(String[] args) {
        MathFunc mc1 = new MathFunc();
        System.out.println(mc1.circleLenght(5));
        System.out.println(mc1.absComplex(2,5));
    }
}
