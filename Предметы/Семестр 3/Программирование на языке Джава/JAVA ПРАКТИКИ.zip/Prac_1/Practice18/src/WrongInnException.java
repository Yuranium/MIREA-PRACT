public class WrongInnException extends RuntimeException {
    public WrongInnException(String errorMessage) {
        super(errorMessage);
    }
}