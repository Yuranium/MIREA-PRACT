
public class Main {
    public static void main(String[] args) {
        int[] array = { 2,4,6,8,10,12,14,16,18,20 };                // Инициализация массива
        int summa = 0;
        for (int i : array) { summa+=i; }                // Проходим по массиву с помощью итератора и суммируем значение
        int mean = 0;
        mean = summa / array.length;                     // Вычисление среднего арифметического

        System.out.printf("Сумма элементов массива = " );
        System.out.println(summa);
        System.out.printf("Среднее арифметическое число массива = " );
        System.out.println(mean);

        }
    }