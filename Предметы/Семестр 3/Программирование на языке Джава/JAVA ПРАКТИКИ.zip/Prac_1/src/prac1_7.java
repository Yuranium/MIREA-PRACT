import java.util.Scanner;
public class prac1_7 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);         // объявляем Scanner
        int f = input.nextInt();                        // значение вводим с клавиатуры
        System.out.printf("Факториал  этого числа равен ");
        getFactorial(f);
    }

        public static void getFactorial(int f) {
            for (int i = (f - 1); i > 1; i--)            // Цикл для вычисления факториала
            {
                f = f * i;
            }
            System.out.println(f);                       // Вывод результата
        }
    }
