import java.util.Scanner; // // импорт сканнера
public class prac1_4 {
    public static void main(String[] args) {
        int[] array = new int[10];
        int summa = 0, i = 0, maximum = 0, minimum = 0;
        Scanner input = new Scanner(System.in);    //  Объявляем Scanner
        // int size = input.nextInt();
        do
        {
            array[i] =  input.nextInt();                // читаем с клавиатуры число в массив
            summa += array[i];                          // считаем сумму
            i++;

        } while (i < array.length);                     // считываем числа пока не дойдём до конца массива (10)

        for (int x = 0;  x < array.length; x++ )        // проходим по массиву
        {
            if (array[x] < minimum ) { minimum = array[x]; }
            if (array[x] > maximum ) { maximum = array[x]; }

        }
        System.out.println("Сумма чисел массива = " + summa);
        System.out.println("Минимальное число массива = " + minimum);
        System.out.println("Максимальное число массива = " + maximum);

    }

}
