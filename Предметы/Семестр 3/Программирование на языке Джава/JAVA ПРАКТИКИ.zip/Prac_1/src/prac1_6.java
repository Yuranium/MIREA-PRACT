public class prac1_6 {
    public static void main(String[] args) {
        System.out.printf("Первые десять чисел гармонического ряда \n");
        for (int i = 1; i < 11; i++) {              // первые 10 чисел
            double value  = Math.round((1./i) * 100.0) / 100.0;                 // вывод числа с округлением до 2 знаков
            System.out.println(value);
        }
    }
}

