import java.text.NumberFormat;
import java.text.DecimalFormat;
import java.util.Locale;
import java.util.Scanner;
public class Formatting_lines_of_code {
        public double Ruble_to_Dollar(double amount) { return amount * 0.010; }
        public double Ruble_to_Euro(double amount) { return amount * 0.0097; }
        public double Ruble_to_PoundSterling(double amount) { return amount * 0.0084; }
        public double Ruble_to_yuna(double amount) { return amount * 0.075; }
        public double Dollar_to_Ruble(double amount) { return amount * 96.52; }
        public double Dollar_to_Euro(double amount) { return amount * 0.94; }
        public double Dollar_to_PoundSterling(double amount) { return amount * 0.81; }
        public double Dollar_to_yuna(double amount) { return amount * 7.29; }
        public double Euro_to_Ruble(double amount) { return amount * 103.11; }
        public double Euro_to_Dollar(double amount) { return amount * 1.07; }
        public double Euro_to_PoundSterling(double amount) { return amount * 0.86; }
        public double Euro_to_yuna(double amount) { return amount * 7.78; }
        public double Sterling_to_Ruble(double amount) { return amount * 119.29; }
        public double Sterling_to_Dollar(double amount) { return amount * 1.24; }
        public double Sterling_to_Euro(double amount) { return amount * 1.16; }
        public double Sterling_to_yuna(double amount) { return amount * 9.1; }
        public double Yuna_to_Ruble(double amount) { return amount * 13.25; }
        public double Yuna_to_Dollar(double amount) { return amount * 0.14; }
        public double Yuna_to_Euro(double amount) { return amount * 0.13; }
        public double Yuna_to_Sterling(double amount) { return amount * 0.11; }

    public static void main(String[] args) {

        NumberFormat numberFormat1 = NumberFormat.getCurrencyInstance(Locale.US);
        NumberFormat numberFormat2 = NumberFormat.getCurrencyInstance(Locale.FRANCE);
        NumberFormat numberFormat3 = NumberFormat.getCurrencyInstance(Locale.UK);
        NumberFormat numberFormat4 = NumberFormat.getCurrencyInstance(Locale.CHINA);
        System.out.printf("Введите сумму, которую хотите конвертировать\n");
        Scanner input = new Scanner(System.in);
        double amount  = input.nextDouble();
        Formatting_lines_of_code object1 = new Formatting_lines_of_code();
        System.out.printf("В какой валюте сумма?\n");
        System.out.printf("Подсказка - Dollar, Euro, Ruble, Yuna, Sterling\n\n");

        String str = input.next();
        switch (str) {
            case "Dollar":
                System.out.printf("Сумма в евро = " + numberFormat2.format(object1.Dollar_to_Euro(amount))+"\n");
                System.out.printf("Сумма в фунт стерлингов = "+ numberFormat3.format(object1.Dollar_to_PoundSterling(amount))+"\n");
                System.out.printf("Сумма в юань = "+ numberFormat4.format(object1.Dollar_to_yuna(amount))+"\n" );
                System.out.println("Сумма в рублях = " + object1.Dollar_to_Ruble(amount)+ " ₽");
                break;
            case "Euro" :
                System.out.printf("Сумма в долларах = " + numberFormat1.format(object1.Euro_to_Dollar(amount))+"\n");
                System.out.printf("Сумма в фунт стерлингов = "+ numberFormat3.format(object1.Euro_to_PoundSterling(amount))+"\n");
                System.out.printf("Сумма в юань = " + numberFormat4.format(object1.Euro_to_yuna(amount))+"\n" );
                System.out.println("Сумма в рублях = " + object1.Euro_to_Ruble(amount)+ " ₽");
                break;
            case "Ruble" :
                System.out.printf("Сумма в долларах = " + numberFormat1.format(object1.Ruble_to_Dollar(amount))+"\n");
                System.out.printf("Сумма в фунт стерлингов = "+ numberFormat3.format(object1.Ruble_to_PoundSterling(amount))+"\n");
                System.out.printf("Сумма в юань = " + numberFormat4.format(object1.Ruble_to_yuna(amount))+"\n" );
                System.out.printf("Сумма в евро = " + numberFormat2.format(object1.Ruble_to_Euro(amount))+"\n");
                break;
            case "Sterling" :
                System.out.printf("Сумма в евро = " + numberFormat2.format(object1.Sterling_to_Euro(amount))+"\n");
                System.out.printf("Сумма в долларах = "+ numberFormat1.format(object1.Sterling_to_Dollar(amount))+"\n");
                System.out.printf("Сумма в юань = "+ numberFormat4.format(object1.Sterling_to_yuna(amount))+"\n" );
                System.out.println("Сумма в рублях = " + object1.Sterling_to_Ruble(amount)+ " ₽");
                break;
            case "Yuna" :
                System.out.printf("Сумма в евро = " + numberFormat2.format(object1.Yuna_to_Euro(amount))+"\n");
                System.out.printf("Сумма в долларах = "+ numberFormat1.format(object1.Yuna_to_Dollar(amount))+"\n");
                System.out.printf("Сумма в стерлингах = "+ numberFormat3.format(object1.Yuna_to_Sterling(amount))+"\n" );
                System.out.println("Сумма в рублях = " + object1.Yuna_to_Ruble(amount)+ " ₽");
                break;
            default:
                System.out.println("Ошибка. Неправильный ввод");
        }
        }
    }


