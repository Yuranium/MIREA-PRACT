import java.lang.reflect.Modifier;

public class Shells {
    public static void main(String[] args) {

        Double digit_1 = Double.valueOf(5);     // 1. Создайте объекты класса Double, используя методы valueOf().
        Double digit_2 = Double.valueOf(14);
        System.out.println(digit_1);
        System.out.println(digit_2);

        String str = "500";                        // 2. Преобразовать значение типа String к типу double. Используем метод Double.parseDouble()
        Double str_digit = Double.parseDouble(str);
        System.out.println(str_digit);

        byte a = digit_1.byteValue();              // 3. Преобразовать объект класса Double ко всем примитивным типам
        System.out.println(a);                     // 4. Вывести значение объекта Double на консоль.

        short s = digit_1.shortValue();
        System.out.println(s);

        int i = digit_1.intValue();
        System.out.println(i);

        long l = digit_1.longValue();
        System.out.println(l);

        float f = digit_1.floatValue();
        System.out.println(f);


        String str_d2 = Double.toString(3.14);      // 5. Преобразовать литерал типа double к строке: String d = Double.toString(3.14)
        System.out.println(str_d2);

    }

}
