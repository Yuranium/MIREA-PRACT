import  java.util.Random;
public class Math_and_Random_tasks_3 {

    public static void main(String[] args) {
        double[] array = new double[4];
        Random random = new Random();
        for (int i = 0; i < 4; i++)             // заполним массив через цикл
        {
            // array[i] = i * 10;    - если надо проверить, что код правильно определяет последовательность
            array[i] = 10 + random.nextDouble(100-10);      // заполним числами от 10 до 99
        }
        System.out.printf("Массив[10;99] = ");                     // вывод массива в строчку
        for (int i =0; i < 4; i++)
        {
            System.out.printf("   " + array[i]);
        }
        boolean status = false;
        for (int i = 0;i<3;i++) {                                  // через цикл проверяем: строго возрастающая последовательность?
            if (array[i + 1] > array[i]) {
                status = true;
            }
            else {
                status = false;
                break;
            }

        }
        System.out.println("");
        if (status == true) {
            System.out.println("Последовательность строго возрастающая"); }
        else {
            System.out.println("Последовательность не строго возрастающая"); }
    }
}
