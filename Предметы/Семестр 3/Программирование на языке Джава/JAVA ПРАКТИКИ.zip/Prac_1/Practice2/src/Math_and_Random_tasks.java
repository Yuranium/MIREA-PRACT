import java.util.Random;
import java.util.Scanner;
public class Math_and_Random_tasks {
    public static void array_with_Math_random(double[] array) {         // Заполнить массив с помощью Math.random
        for (int i = 0; i < array.length; i++) {
            array[i] = Math.random() * 5;

        }
    }
    public static void array_with_ClassRandom(double[] array) {         // Заполнить массив с помощью Random
        Random random = new Random();
        for (int j=0;j<array.length;j++) {
            array[j] = random.nextDouble();  }

    }

    public static void main(String[] args) {
        System.out.printf("Введите размер массива:\n");
        Scanner input =  new Scanner(System.in);
        int scan = input.nextInt();
        double[] array = new double[scan];

        System.out.printf("С помощью какого класса сгенерировать массив?\n");
        System.out.printf("1 - class Math\n2 - class Random\n");
        int scan_class_of_array = input.nextInt();
        Math_and_Random_tasks sc = new Math_and_Random_tasks();
        if (scan_class_of_array == 1) {sc.array_with_Math_random(array); };           // class Math
        if (scan_class_of_array == 2) {sc.array_with_ClassRandom(array); };           // class Random


        System.out.printf("Случайно сгенерированный НЕотсортированный массив:\n");    // Вывод массива
        for (int i = 0; i < array.length; i++) {
            System.out.println(array[i]);
        }
        System.out.printf("\n");
        double temp = 0;
        for (int i = 0; i < array.length; i++) {                                      // сортировка массива пузырьком
            for (int j = 1; j < array.length; j++) {
                if (array[j - 1] > array[j]) {
                    //swap элементов
                    temp = array[j - 1];
                    array[j - 1] = array[j];
                    array[j] = temp;
                }
            }
        }
        System.out.printf("Отсортированный массив:\n\n");                             // вывод отсортированного массива
        for (int i = 0; i < array.length; i++) {
            System.out.println(array[i]);
        }
    }
}
