public class Exception1 {
    public static void exceptionDemo(){
        System.out.println(2 / 0);
    }
    public static void main(String[] args) {
        Exception1.exceptionDemo();
    }
}