public class Main {
    public static void main(String[] args) {
        DataTime test = new DataTime();
        test.firstTask();
        test.secondTask();
        test.thirdTask();
        test.fourthTask();
        test.fifthTask();
    }
}
